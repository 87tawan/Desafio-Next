import ForButtons from "@/components/ForButtons"
export default function Home () {
    return (
        <ForButtons></ForButtons>
    )
}