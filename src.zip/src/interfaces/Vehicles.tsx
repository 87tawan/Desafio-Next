
export interface DataFormVehicles {
    placa: string,
    marcaModelo: string,
    anoFabricacao: number,
    kmAtual: number
  }
  
  export interface DataFormVehiclesPut {
    placa: string,
    marcaModelo: string,
    anoFabricacao: number,
    kmAtual: number
  }
  